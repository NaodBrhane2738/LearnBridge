LearnBridge sample offline lesson pack

This is synthetic prototype content for UI testing only. It is not ALX course content and has not been validated as an accessible training deliverable.
